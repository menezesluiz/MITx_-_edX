# -*- coding: utf-8 -*-
"""
Created on Wed Jun  8 19:15:34 2016

@author: ericgrimson
"""

US = ['MIT', 'Harvard', 'Yale']
UK = ['Cambridge', 'Oxford']

Unis = [US, UK]
Unisnew = [['MIT', 'Harvard', 'Yale'], ['US', 'UK']]

# US.append('Princeton')